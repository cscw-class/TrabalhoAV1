var http = require('http');

var server = http.createServer(function(req,res){
	var categoria = req.url;

	if ( categoria == '/roupas'){
		res.end("<html><body><h1>Lista de Roupas</h1></body></html>");
	} else if(categoria == '/eletronicos'){
		res.end("<html><body><h1>Lista de Eletrônicos</h1></body></html>");
	}else{
		res.end("<html><body><h1>Lista de Produtos</h1></body></html>");
	}
});

server.listen(3000);